var dynmapversion = "3.7-SNAPSHOT-949";

